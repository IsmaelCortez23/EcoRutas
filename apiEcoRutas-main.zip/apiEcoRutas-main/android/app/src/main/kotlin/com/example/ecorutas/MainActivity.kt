package com.example.ecorutas

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
